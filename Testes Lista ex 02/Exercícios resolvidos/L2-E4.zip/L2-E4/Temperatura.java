// F=1,8C+32
// K=C+273
public class Temperatura {
    private double celsius;
    private double fahrenheit;
    private double kelvin;
    
    public void setCelsius(double celsius) {
        this.celsius = celsius;
        fahrenheit = 1.8 * celsius + 32;
        kelvin = celsius + 273.15;
    }
    
    public double getCelsius() {
        return celsius;
    }
    
    public void setFahrenheit(double fahrenheit) {
        this.fahrenheit = fahrenheit;
        celsius = (fahrenheit - 32) / 1.8;
        kelvin = celsius + 273.15;
    }
    
    public double getFahrenheit() {
        return fahrenheit;
    }
    
    public void setKelvin(double kelvin) {
        this.kelvin = kelvin;
        celsius = kelvin - 273.15;
        fahrenheit = 1.8 * celsius + 32; 
    }
    
    public double getKelvin() {
        return kelvin;
    }
}