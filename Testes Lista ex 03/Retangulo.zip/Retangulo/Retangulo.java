public class Retangulo
{
    private double base;
    private double altura;

    public Retangulo() {
        //base = 1;
        //altura = 1;
        this(1);
    }

    public Retangulo(double valor) {
        //base = valor;
        //altura = valor;
        //setBase(valor);
        //setAltura(valor);
        this(valor, valor);
    }

    public Retangulo(double base, double altura) {
        //this.base = base;
        //this.altura = altura;
        setBase(base);
        setAltura(altura);
    }

    public void setBase(double base) {
        this.base = base;
    }

    public double getBase() {
        return base;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public double getAltura() {
        return altura;
    }

    public double getArea() {
        return base * altura;
    }

    public double getPerimetro() {
        return 2 * base + 2 * altura;
    }

    public boolean eQuadrado() {
        return base == altura;
    }
    
    public boolean temAreaMaiorQue(double area) {
        return getArea() > area;
    }
    
    public boolean temAreaMaiorQue(Retangulo r) {
        return getArea() > r.getArea();
    }
}