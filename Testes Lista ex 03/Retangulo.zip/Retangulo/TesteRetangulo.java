import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TesteRetangulo
{
    private Retangulo r;
    
    @BeforeEach
    public void antesDeCadaTeste() {
        r = new Retangulo(5, 10);
    }
    
    @Test
    public void deveSerPossivelInstanciarUsandoOConstrutorPardrao() {
        r = new Retangulo();

        assertEquals(1, r.getBase());
        assertEquals(1, r.getAltura());
    }

    @Test
    public void deveInstanciarInformandoUmArgumento() {
        r = new Retangulo(10);

        assertEquals(10, r.getBase());
        assertEquals(10, r.getAltura());
    }

    @Test
    public void deveInstanciarInformandoABaseEAltura() {
        assertEquals(5, r.getBase());
        assertEquals(10, r.getAltura());
    }

    @Test
    public void deveAlterarABasePeloSet() {
        r.setBase(15);

        assertEquals(15, r.getBase());
    }

    @Test
    public void deveAlterarAAlturaPeloSet() {
        r.setAltura(20);

        assertEquals(20, r.getAltura());
    }

    @Test
    public void deveRetonarAArea() {
        assertEquals(50, r.getArea());
    }

    @Test
    public void deveRetornarOPerimetro() {
        assertEquals(30, r.getPerimetro());
    }

    @Test
    public void deveInformarSeEQuadrado() {
        r = new Retangulo();
        assertTrue(r.eQuadrado());

        r.setBase(5);
        assertFalse(r.eQuadrado());
    }

    @Test
    public void deveInformarSeTemaAreaMaiorQueUmValorInformado() {
        assertTrue(r.temAreaMaiorQue(30));
        assertFalse(r.temAreaMaiorQue(60));
    }

    @Test
    public void deveInformarSeTemAreaMaiorQueOutroRetangulo() {
        Retangulo r1 = new Retangulo(10, 10);

        assertFalse(r.temAreaMaiorQue(r1));
        assertTrue(r1.temAreaMaiorQue(r));
    }
}