import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

public class TesteReta {
	private static final double DELTA = 0.001;

	private Reta r;
	private Reta s;

	@Before
	public void antesDeCadaTeste() {
		r = new Reta(2, 1);
		s = new Reta(1, 2);
	}

	@Test
	public void devePossuirOCoeficienteAngularConformeArgumentoNoConstrutor() {
		assertEquals(2, r.getCoeficienteAngular(), DELTA);
		assertEquals(1, s.getCoeficienteAngular(), DELTA);
	}
	
	@Test
	public void devePossuirOCoeficienteLinearConformeArgumentoNoConstrutor() {
		assertEquals(1, r.getCoeficienteLinear(), DELTA);
		assertEquals(2, s.getCoeficienteLinear(), DELTA);
	}

	@Test
	public void deveRetonarAEqucaoDaReta() {
		assertEquals("y = 2.0x + 1.0", r.getEquacaoDaReta());
		assertEquals("y = 1.0x + 2.0", s.getEquacaoDaReta());
	}
	
	@Test
	public void deveRetonarOPontoDeIntersecaoDaRetal() {
		assertEquals("P(1.0,3.0)", r.getPontoInterseccao(s).getRepresentacao());
	}
	
	@Test
	public void deveVerificarSeOPontoPerteceAReta() {
		assertTrue(r.oPontoPertenceAReta(new Ponto(2, 5)));
	}
}
