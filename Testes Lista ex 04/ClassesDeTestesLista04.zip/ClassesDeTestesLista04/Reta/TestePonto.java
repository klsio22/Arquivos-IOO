import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

public class TestePonto {
	private static final double DELTA = 0.001;

	private Ponto p;

	@Before
	public void antesDeCadaTeste() {
		p = new Ponto(2, 1);
	}

	@Test
	public void devePossuirXConformeDefinidoNoConstrutor() {
		assertEquals(2, p.getX(), DELTA); 
	}

	@Test
	public void devePossuirYConformeDefinidoNoConstrutor() {
		assertEquals(1, p.getY(), DELTA); 
	}

	@Test
	public void devePermitirAlteraroEixoX() {
		p.setX(10);
		assertEquals(10, p.getX(), DELTA); 
	}
	
	@Test
	public void devePermitirAlteraroEixoY() {
		p.setY(10);
		assertEquals(10, p.getY(), DELTA); 
	}
	
	@Test
	public void deveRetornarARepresentacaoTextual() {
		assertEquals("P(2.0,1.0)", p.getRepresentacao()); 
	}
}
