import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TesteCorrida {
	
	private Corrida corrida;
	
	/* ========================================================
	 * 
	 * Charrete A vence.
	 * ------------------------------------------------------
	 */
	@Test
	public void deveRetornarONumeroDaCharreteAComoVencedora() {
		corrida = new Corrida(new Charrete(45, 40, 900),
							  new Charrete(17, 20, 300));
		
		assertEquals(17, corrida.getCharreteVencedora());
	}
	
	/* ========================================================
	 * 
	 * Charrete B vence.
	 * ------------------------------------------------------
	 */
	@Test
	public void deveRetornarONumeroDaCharreteBComoVencedora() {
		corrida = new Corrida(new Charrete(1, 100, 1000),
							  new Charrete(2, 99, 1000));
		
		assertEquals(2, corrida.getCharreteVencedora());
	}
}
