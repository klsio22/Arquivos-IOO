import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

public class TesteCharrete {
	
	// Precisação da comparação de dois números com vírgula.
	// Math.abs(expected - actual) < DELTA
	private static final double DELTA = 0.002;
	
	private Charrete charrete;
	
	@Before
	public void antesDeCadaTeste() {
		charrete = new Charrete(1, 100, 200); 
	}
	
	/* ========================================================
	 * 
	 * Inicialização
	 * ------------------------------------------------------
	 */
	@Test
	public void deveSerPossivelInstaciarUsandoConstrutor() {
		assertEquals(1, charrete.getNumero());
		assertEquals(100, charrete.getVelocidade());
		assertEquals(200, charrete.getDistanciaAteAChegada());
	}
	
	/* ========================================================
	 * 
	 * Sets
	 * ------------------------------------------------------
	 */
	@Test
	public void deveSerPossivelAlterarUsandoMetodosSets() {
		charrete.setNumero(2);
		charrete.setVelocidade(200);
		charrete.setDistanciaAteAChegada(400);
		
		assertEquals(2, charrete.getNumero());
		assertEquals(200, charrete.getVelocidade());
		assertEquals(400, charrete.getDistanciaAteAChegada());
	}

	/* ========================================================
	 * 
	 * Tempo até a linha de chegada.
	 * ------------------------------------------------------
	 */
	@Test
	public void deveRetonarOTempoAteAChegada() {
		assertEquals(2, charrete.getTempoAteAChegada(), DELTA);
		
		charrete.setNumero(2);
		charrete.setVelocidade(200);
		charrete.setDistanciaAteAChegada(400);
		
		assertEquals(2, charrete.getTempoAteAChegada(), DELTA);
	}
	
}
