import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

public class TesteContador {
    private Contador pn;
    
    @Before
    public void antesDeCadaTeste()
    {
        pn = new Contador(15);
    }

    @Test
    public void deveIncrementarPainelNumericoEmUm() {
        int valor = pn.getValor();
        pn.incrementa();
        
        assertEquals(valor+1, pn.getValor());
    }
    
    @Test
    public void deveAlterarOValorSomenteDentroDoIntervalo() {
        pn.setValor(5);
        assertEquals(5, pn.getValor());
        
        pn.setValor(20);
        assertEquals(5, pn.getValor());

        pn.setValor(-1);
        assertEquals(5, pn.getValor());
    }
    
    @Test
    public void deveRetornarOValorComZeroSeMenorQue10() {
        assertEquals("00", pn.getValorExibido());
        
        pn.setValor(9);
        assertEquals("09", pn.getValorExibido());
        
        pn.setValor(10);
        assertEquals("10", pn.getValorExibido());
    }
}
