public class Principal {

    private Principal(){}
    
    public static void main(String[] args) {
        InterfaceTexto i = new InterfaceTexto();
        i.renderizar();
    }
}
