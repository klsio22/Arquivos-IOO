public class Nota {
    private String texto;
        
    public void setTexto(String texto) {
        this.texto = texto;
    }
    
    public String getTexto() {
        return texto;
    }
}
