public class Principal {

    public static void main(String[] args) {
        Pessoa p = new Pessoa();
        p.setNome("Eleandro");
        System.out.println(p.getNome());
    }
}
