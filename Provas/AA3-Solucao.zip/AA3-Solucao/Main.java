public class Main {
    public static void main(String[] args) {
        // Aluno aluno = new Aluno();
        // Aluno alunoUm = new Aluno();
        
        // System.out.println(aluno);
        // System.out.println(aluno.toString());
        // System.out.println();
        // System.out.println(alunoUm);
        // System.out.println(alunoUm.toString());
        
        String s = "Diego";
        String s1 = new String("Diego");
        
        System.out.println(s.equals(s1));
        System.out.println(s1);
    }
}